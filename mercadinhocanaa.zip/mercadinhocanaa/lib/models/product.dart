import 'package:flutter/material.dart';
import 'package:mercadinhocanaa/models/single_product.dart';

class Product extends StatefulWidget {
  @override
  _ProductState createState() => _ProductState();
}

class _ProductState extends State<Product> {
  var productList = [
    {
      "name": "Absorvente Higiênico",
      "picture": "img/Produtos/01.png",
      "preco": 4.60
    },
    {
      "name": "Cereal Integral Snow Flakes",
      "picture": "img/Produtos/02.png",
      "old price": 120,
      "preco":3.50
    },
    {
      "name": "Iorgute ",
      "picture": "img/Produtos/3.png",
      "old price": 120,
      "preco": 85
    },
    {
      "name": "Cereal Integral Crunch",
      "picture":"img/Produtos/03.png",
      "old price": 120,
      "preco": 85
    },
    {
      "name": "Batgut Morango",
      "picture": "img/Produtos/4.png",
      "old price": 120,
      "preco": 85.99
    },
    {
      "name": "Iorgute Betânia Ameixa",
      "picture": "img/Produtos/5.png",
      "old price": 120,
      "price": 85
    },
    {
      "name": "Danone Morango Betânia",
      "picture": "img/Produtos/6.png",
      "old price": 120,
      "price": 85
    },
    {
      "name": "Feijoada Oderich",
      "picture": "img/Produtos/06.png",
      "old price": 120,
      "price": 85
    },
    {
      "name": "SKT",
      "picture": "img/Produtos/07.png",
      "old price": 120,
      "price": 85
    },
    {
      "name": "SKT",
      "picture": "img/Produtos/10.png",
      "old price": 120,
      "preço": 85
    },
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: productList.length,
        gridDelegate:
            new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 0.7),
        itemBuilder: (BuildContext context, int index) {
          return SingleProduct(
            productName: productList[index]['name'],
            productPicture: productList[index]['picture'],
            productOldPrice: productList[index]['old price'],
            productPrice: productList[index]['preco'],
          );
        });
  }
}
