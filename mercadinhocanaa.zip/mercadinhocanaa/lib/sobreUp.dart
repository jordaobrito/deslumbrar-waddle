import 'package:flutter/material.dart';

class SobreUp extends StatefulWidget {
  @override
  _SobreUpState createState() => _SobreUpState();
}

class _SobreUpState extends State<SobreUp> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Nossa Empresa"
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(10),
          child:Column(

            children: <Widget>[
              Column(

                children: <Widget>[
                  Image.asset("img/banner/mcanaa.png",
                      fit: BoxFit.fill,
                      width: MediaQuery.of(context).size.width - 200

                  ),
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: Text(
                      "Sobre a Empresa",
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.deepOrange
                      ),
                    ),
                  )
                ],
              ),
              Padding(
                padding: EdgeInsets.only(top: 16),
                child: Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum"),
              )
            ],

          ) ,

        ),
      ),
    );
  }
}




