import 'package:flutter/material.dart';
import 'package:mercadinhocanaa/feedback.dart';
import 'package:mercadinhocanaa/home.dart';
import 'package:mercadinhocanaa/signUp.dart';
import 'package:mercadinhocanaa/sobreUp.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mercadinho Canaã',
      theme: ThemeData(
        primarySwatch: Colors.yellow,
      ),
      home: Home(),
      routes: {
        '/signUp': (context) => SignUp(),
        '/feedback': (context) => feedback(),
        '/home': (context) => Home(),
        '/sobreUp': (context) => SobreUp(),
      },
    );
  }
}