import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:mercadinhocanaa/models/product.dart';

class Category extends StatefulWidget {
  final String title;

  const Category({Key key, this.title}) : super(key: key);

  @override
  _CategoryState createState() => _CategoryState();
}

class _CategoryState extends State<Category> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),

      body: Column(


        children: <Widget>[




          Expanded(
            child: Container(
              child: Product(),
            ),
            flex: 4,
          )
        ],
      ),
    );
  }





}
