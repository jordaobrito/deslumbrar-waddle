import 'package:flutter/material.dart';
import 'package:mercadinhocanaa/category.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';

class Home extends StatefulWidget {
  Home({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  var categories = [
    {
      'title': 'Limpeza',
      'img': 'img/614639.png',
    },
    {
      'title': 'Bebidas',
      'img': 'img/Produtos/vinhos.png',
    },
    {
      'title': 'Carnes,Aves e Peixes',
      'img': 'img/Produtos/bomtodo.jpg',
    },
    {
      'title': 'Congelados',
      'img': 'img/Produtos/hamburguer.jpg',
    },
    {
      'title': 'Frios e Laticinios',
      'img': 'img/Produtos/mortadela.jpg',
    },
    {
      'title': 'Higiene e Beleza',
      'img': 'img/Produtos/suave.png',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Mercadinho Canaã"),
      ),
      drawer: buildDrawer(),
      body: buildBody(),
    );
  }

  Widget buildBody() {
    return GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, childAspectRatio: 0.8),
        itemCount: 6,
        itemBuilder: (context, i) {
          return InkWell(
            child: Container(
              margin: EdgeInsets.all(5),
              child: Card(
                elevation: 2,
                child: Container(
                  child: Container(
                    color: Color.fromRGBO(0, 0, 0, 0.4),
                    child: buildTitle(categories[i]['title']),
                  ),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(categories[i]['img']),
                        fit: BoxFit.fill),
                  ),
                ),
              ),
            ),
            onTap: () => {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => Category(
                                title: categories[i]['title'],
                              )))
                },
          );
        });
  }

  Widget buildTitle(String title) {
    return Center(
      child: Container(
        child: Text(
          title,
          style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),
        ),
        padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
        decoration: BoxDecoration(
            border: Border.all(
                width: 2, color: Colors.white, style: BorderStyle.solid)),
      ),
    );
  }

  Future<bool> _onWillPop() {
    return showDialog(
          context: context,
          builder: (context) => new AlertDialog(
                title: new Text('Are you sure?'),
                content: new Text('Do you want to exit an App'),
                actions: <Widget>[
                  new FlatButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: new Text('No'),
                  ),
                  new FlatButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    child: new Text('Yes'),
                  ),
                ],
              ),
        ) ??
        false;
  }

  Widget buildDrawer() {
    return Drawer(
      child: Column(
        children: <Widget>[
          Expanded(
            flex: 2,
            child: UserAccountsDrawerHeader(
//              decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/mazzad.png"))),
              accountName: Text("Mercadinho Canaã",
                style: TextStyle(
                  fontSize: 25,
                  fontFamily:"Roboto",
                  fontWeight: FontWeight.bold,
                ),
              ),
              accountEmail: Text("Mania de Vender Barato!",
              style: TextStyle(
                fontFamily: "Roboto",
              ),),
              currentAccountPicture: CircleAvatar(
                backgroundImage: AssetImage("img/banner/logo1.jpg"),
                radius: 60,
              ),
            ),
          ),
          Expanded(
              flex: 5,
              child: ListView(
                shrinkWrap: true,
                children: <Widget>[

                  Divider(),
                  buildSeparators("Midias Sociais e Pagamentos"),
                  // with custom text
                  SignInButton(
                    Buttons.Facebook,
                    text: "Facebook",
                    onPressed: () {},
                  ),
                  SignInButton(
                    Buttons.Email,
                    text: "Email",
                    onPressed: () {},
                  ),
                  SignInButton(
                    Buttons.Google,
                    text: "Google",
                    onPressed: () {},
                  ),
                  SignInButton(
                    Buttons.Twitter,
                    text: "Twitter",
                    onPressed: () {},
                  ),

                  Divider(),
                  buildSeparators("Nossa Empresa"),
                  buildTile(
                    "Sobre Pagamentos",
                    "/signUp",
                    'img/menulateral/pagamento.png',
                  ),
                  buildTile(
                    "Contato",
                    "/feedback",
                    'img/menulateral/contato.png',
                  ),
                  buildTile(
                    "Sobre Nos",
                    "/sobreUp",
                    'img/menulateral/sobrenos.png',
                  ),

                ],
              ))
        ],
      ),
    );
  }

  Widget buildSeparators(String name) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Padding(padding: EdgeInsets.only(left: 10)),
        Text(
          name,
          style: TextStyle(
              fontStyle: FontStyle.italic,
              fontWeight: FontWeight.bold,
              fontSize: 20),
        ),
      ],
    );
  }

  Widget buildTile(String name, String path, String imgPath) {
    return ListTile(
      leading: Image.asset(
        imgPath,
        scale: 1.2,
      ),
      title: Text(name),
      onTap: () {
        if ( path != '/login' && path != '/signUp' && path != '/sobreUp' && path != '/feedback'  )
          Navigator.pop(context);
        else
          Navigator.pushNamed(context, path);
      },
    );
  }
}
